#ifndef TORCH_CHECK
#define TORCH_CHECK AT_CHECK
#endif
